package com.arnaldo.movies.event;

public class UpdateFavoritesEvent {

    public UpdateFavoritesEvent() {

    }
}
